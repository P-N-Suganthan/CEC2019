/*
DISHchain1e+12 algorithm runtime code for GECCO2019 Workshop / CEC2019 Special Session / Competition on 100-Digit Challenge on Single Objective Numerical Optimization

Author: Ales Zamuda <ales.zamuda@um.si>

Paper:
A. Zamuda. Function evaluations upto 1e+12 and large population sizes assessed in distance-based success history differential evolution for 100-digit challenge and numerical optimization scenarios (DISHchain1e+12): a competition entry for “100-digit challenge, and four other numerical optimization competitions” at the genetic and evolutionary computation conference (GECCO) 2019. Proceedings of the Genetic and Evolutionary Computation Conference Companion (GECCO 2019), 2019, pp. 11-12. 

Date: 30 January 2019


Sidenotes:

*
This code was also used at FES settings 3e+12 for presentation:
Aleš Zamuda. Solving 100-Digit Challenge with Score 100 by Extending Running Time. 7-th Joint International Conferences on Swarm, Evolutionary and Memetic Computing Conference (SEMCCO 2019) & Fuzzy And Neural Computing Conference (FANCCO 2019), Maribor, Slovenia, EU, 10-12 July 2019.

*
The base of this code was also used for baseline algorithm DISH that uses CEC 2017 functions, published in:
A. Viktorin, R. Senkerik, M. Pluhacek, T. Kadavy, A. Zamuda. Distance Based Parameter Adaptation for Success-History based Differential Evolution. Swarm and Evolutionary Computation, Available online 12 November 2018. DOI 10.1016/j.swevo.2018.10.013

*/

/*

    These files are the code of "jSO" for Special Session & Competition on Real-Parameter Single Objective Optimization at CEC-2017 (see [1])

       [1] Janez Brest, Mirjam Sepesy Maucec, Borko Boskovic. Single Objective Real-Parameter Optimization: Algorithm jSO, 
           Proc. IEEE Congress on Evolutionary Computation (CEC-2017), Donostia - San Sebastián, Spain, June 2017.

   jSO is improved version of i-LSHADE.
   iL-SHADE: Improved L-SHADE Algorithm (L-SHADE was proposed by Ryoji Tanabe and Alex Fukunaga at CEC2014).
   Many thanks to Ryoji Tanabe and Alex Fukunaga for providing L-SHADE.

*/


/*
  L-SHADE implemented by C++ for Special Session & Competition on Real-Parameter Single Objective Optimization at CEC-2014
  See the details of L-SHADE in the following paper:

  * Ryoji Tanabe and Alex Fukunaga: Improving the Search Performance of SHADE Using Linear Population Size Reduction,  Proc. IEEE Congress on Evolutionary Computation (CEC-2014), Beijing, July, 2014.
  
  Version: 1.0   Date: 16/Apr/2014
  Written by Ryoji Tanabe (rt.ryoji.tanabe [at] gmail.com)
*/

#include "de.h"
#include <algorithm>

#ifndef CEC2019
//double *OShift,*M,*y,*z,*x_bound;
//int ini_flag=0,n_flag,func_flag,*SS;
#endif

int g_function_number;
int g_problem_size;
unsigned long long g_max_num_evaluations;

int g_pop_size;
double g_arc_rate;
int g_memory_size;
double g_p_best_rate;

int g_funNrBenchBegin,g_funNrBenchEnd;
ofstream outFile;
int count10digitsCorrect(double);
int countTrials(int digits, const Fitness *bsf_fitness_array, int num_runs);

int main(int argc, char **argv) {
  //number of runs
  int num_runs = 50;
  //int num_runs = 5;
  //int num_runs = 2;
    //dimension size. please select from 10, 30, 50, 100
  const int g_problem_size_arr[] = {9,16,18,10,10,10,10,10,10,10};
  //available number of fitness evaluations 
  //g_max_num_evaluations = g_problem_size * 10000;
  #ifdef G_MAX_NUM_EVALUATIONS
  g_max_num_evaluations = G_MAX_NUM_EVALUATIONS;
  #else
  g_max_num_evaluations = 1e+3;
  #endif
  #ifdef G_FUN_NR_BENCH_BEGIN
  g_funNrBenchBegin = G_FUN_NR_BENCH_BEGIN;
  #else
  g_funNrBenchBegin = 0;
  #endif
   #ifdef G_FUN_NR_BENCH_END
  g_funNrBenchEnd = G_FUN_NR_BENCH_END;
  #else
  g_funNrBenchEnd = 10;
  #endif
  
  int digitsCorrect;

  //random seed is selected based on time according to competition rules
  srand((unsigned)time(NULL));

  ////L-SHADE parameters
  //g_pop_size = (int)round(g_problem_size * 18);
  //g_memory_size = 6;
  //g_arc_rate = 2.6;
  //g_p_best_rate = 0.11;

  //iL-SHADE parameters
  //g_pop_size = (int)round(g_problem_size * 10);    // iL-SHADE=12
  //g_pop_size = (int)round(sqrt(g_problem_size) * log(g_problem_size) * 30);    // iL-SHADE=12;     sqrt()*ln()*30 ... E3
  //g_pop_size = (int)round(sqrt(g_problem_size) * log(g_problem_size) * 20);    // iL-SHADE=12;     sqrt()*ln()*30 ... E4
  g_memory_size = 5;
  g_arc_rate = 1;   
  g_p_best_rate = 0.25;      // iL-SHADE=0.2

 double sum100Digit = 0;
 for (int i = g_funNrBenchBegin; i < g_funNrBenchEnd; i++) {
    g_problem_size = g_problem_size_arr[i];
    //g_pop_size = (int)round(sqrt(g_problem_size) * log(g_problem_size) * 25);    // iL-SHADE=12;     sqrt()*ln()*30 ... E5
    g_pop_size = (int)round(sqrt(g_problem_size) * log(g_problem_size) * 25);    // iL-SHADE=12;     sqrt()*ln()*30 ... E5; DISH=*25

    g_function_number = i + 1;
    cout << "\n-------------------------------------------------------" << endl;
    cout << "Function = " << g_function_number << ", Dimension size = " << g_problem_size << ", g_pop_size[_INIT] = " << g_pop_size << "\n" << endl;

    // raw data: Record function error value (Fi(x)-Fi(x*)) after (0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0)*MaxFES for each run.
    stringstream ss;
    ss << "-" << g_function_number << "-" << g_max_num_evaluations; 
    string tmp(ss.str());
    string fileNameStr="rawData100dig" + tmp + ".dat";
    //cout << fileNameStr << endl;
    char fileName[500];
    strcpy(fileName,fileNameStr.c_str());
    //ofstream outFile(fileName, ios::out);
    outFile.open(fileName, ios::out);

    Fitness *bsf_fitness_array = (Fitness*)malloc(sizeof(Fitness) * num_runs);
    Fitness mean_bsf_fitness = 0;
    Fitness std_bsf_fitness = 0;
    unsigned long long dig100log[11];

    for (int j = 0; j < num_runs; j++) { 
      searchAlgorithm *alg = new LSHADE();
      bsf_fitness_array[j] = alg->run();
      alg->getLog100digitPrecision(dig100log);
      cout << j + 1 << "th run, " << "error value = " << bsf_fitness_array[j] << " 10digits = " << count10digitsCorrect(bsf_fitness_array[j]) << " digitsLog => ";
      for (int l = 0; l < 11; l++)
        cout << dig100log[l] << " ";
      cout << endl;

      delete alg;
    }
  
    for (int j = 0; j < num_runs; j++) mean_bsf_fitness += bsf_fitness_array[j];
    mean_bsf_fitness /= num_runs;

    for (int j = 0; j < num_runs; j++) std_bsf_fitness += pow((mean_bsf_fitness - bsf_fitness_array[j]), 2.0);
    std_bsf_fitness /= num_runs;
    std_bsf_fitness = sqrt(std_bsf_fitness);

    sort(bsf_fitness_array, bsf_fitness_array+num_runs);
    digitsCorrect = 0;
    for (int j = 0; j < num_runs / 2; j++) digitsCorrect += count10digitsCorrect(bsf_fitness_array[j]);
    sum100Digit += digitsCorrect / ((double) num_runs / 2 );

    cout << "\nFunction = " << g_function_number << ", Dimension size = " << g_problem_size << std::setprecision(10) << ",  mean = " << mean_bsf_fitness << ", std = " << std_bsf_fitness << ", AVGhalfSum10digit = " << ( digitsCorrect / (((double) num_runs) / 2 ) );

    cout << " trialsCorrectDigits => ";
    for (int j = 0; j <= 10; j++) cout << " " << countTrials(j, bsf_fitness_array, num_runs);
    cout << endl;
    free(bsf_fitness_array);

    outFile << endl;
  }
  cout << "Fun " << g_function_number << " 100Digit = " << sum100Digit << endl;

  return 0;
}

// returns number of 10-base digits matching 1.0000000000
// in an IEEE-754 encoded double number
int count10digitsCorrect(double f) {
  if (f < 0.0) return 0;
 
  if (f < 0.000000001) return 10;
  if (f < 0.00000001) return 9;
  if (f < 0.0000001) return 8;
  if (f < 0.000001) return 7;
  if (f < 0.00001) return 6;
  if (f < 0.0001) return 5;
  if (f < 0.001) return 4;
  if (f < 0.01) return 3;
  if (f < 0.1) return 2;
  if (f < 1.0) return 1;

  return 0; // if (f >= 1.0 || f < 0.0)
}

int countTrials(int digits, const Fitness *bsf_fitness_array, int num_runs) {
  int trialsSucceed = 0;
  for (int i = 0; i < num_runs; i++)
    if (count10digitsCorrect(bsf_fitness_array[i]) >= digits) trialsSucceed++;
  return trialsSucceed;
}

