%
% Note:
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 1, or (at your option)
% any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details. A copy of the GNU 
% General Public License can be obtained from the 
% Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function [FVr_bestmem,S_bestval,I_nfeval] = deopt(fname,S_struct)

%Modified by FLC \ INAOE 12/26/2016
function [Fit_and_p,FVr_bestmemit, fitMaxVector, objMaxVector, BotherParameters] = ...
    deopt_adaptive(deParameters,caseStudyData,otherParameters,low_habitat_limit,up_habitat_limit,initialSolution)

%-----This is just for notational convenience and to keep the code uncluttered.--------
I_NP         = deParameters.I_NP;
F_weight     = deParameters.F_weight;
F_CR         = deParameters.F_CR;
I_D          = numel(up_habitat_limit); %Number of variables or dimension
deParameters.nVariables=I_D;
FVr_minbound = low_habitat_limit;
FVr_maxbound = up_habitat_limit;
%I_bnd_constr = deParameters.I_bnd_constr; %To use bound constraints
I_itermax    = deParameters.I_itermax;
minGens=deParameters.minIterations;
threshold=deParameters.threshold;
%if exist('deParameters.adaptActivated')==1
adaptDE=deParameters.adaptActivated;
%else
%    adaptDE=0;
%end

%Repair boundary method employed
BRM=deParameters.I_bnd_constr; %1: bring the value to bound violated
                               %2: repair in the allowed range

%F_VTR        = deParameters.F_VTR ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I_strategy   = deParameters.I_strategy; %important variable
fnc=deParameters.fnc;
if exist('otherParameters.signActivated')
signaling_flag=otherParameters.signActivated;
else
    signaling_flag=0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%-----Check input variables---------------------------------------------
if (I_NP < 5)
   I_NP=5;
   fprintf(1,' I_NP increased to minimal value 5\n');
end
if ((F_CR < 0) || (F_CR > 1))
   F_CR=0.5;
   fprintf(1,'F_CR should be from interval [0,1]; set to default value 0.5\n');
end
if (I_itermax <= 0)
   I_itermax = 200;
   fprintf(1,'I_itermax should be > 0; set to default value 200\n');
end

%-----Initialize population and some arrays-------------------------------
%FM_pop = zeros(I_NP,I_D); %initialize FM_pop to gain speed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Taken from Joao code % pre-allocation of loop variables
fitMaxVector = nan(1,I_itermax);
% limit iterations by threshold
fitIterationGap = inf;
noIterationsToGap = deParameters.noIterationsToGap;
gen = 1; %In joao code is epk
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%----FM_pop is a matrix of size I_NPx(I_D+1). It will be initialized------
%----with random values between the min and max values of the-------------
%----parameters-----------------------------------------------------------
% FLC modification - vectorization
minPositionsMatrix=repmat(FVr_minbound,I_NP,1);
maxPositionsMatrix=repmat(FVr_maxbound,I_NP,1);
deParameters.minPositionsMatrix=minPositionsMatrix;
deParameters.maxPositionsMatrix=maxPositionsMatrix;

% generate initial population.
FM_pop=genpop(I_NP,I_D,minPositionsMatrix,maxPositionsMatrix);
if nargin>5
    noInitialSolutions = size(initialSolution,1);
    FM_pop(1:noInitialSolutions,:)=initialSolution;
end

% % Modified by FLC
% otherParameters.signActivated=1; %Just do this once
% [~, ~, FM_pop, otherParameters]=feval(fnc,FM_pop,caseStudyData, otherParameters);
% % check signaling
% [FM_pop,otherParameters] = checkSignaling(FM_pop,otherParameters,deParameters);
% otherParameters.signActivated=0; %Just do this once

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------Evaluate the best member after initialization----------------------
% Modified by FLC
switch fnc
    case 'fitnessFun_DER'
         caseStudyData=caseStudyData(1);
end

%caseStudyData=rmfield(caseStudyData,'probScenario')
%[S_val, obj_pop, FM_pop, otherParameters]=feval(fnc,FM_pop,caseStudyData, otherParameters);
[S_val, obj_pop, ~, otherParameters]=feval(fnc,FM_pop,caseStudyData, otherParameters,10);

[~,I_best_index] = min(S_val);

FVr_bestmemit = FM_pop(I_best_index,:); % best member of current iteration

if deParameters.I_strategy==6;
   [~, ind_best]=sort(S_val); 
   FVr_bestmemit=FM_pop(ind_best(1:ceil(I_NP*0.15)),:); %This strategy is very similar to the one used for PSO modified
end
 
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Taken from joao store other information
otherParameters.idBestParticle = I_best_index;
%otherParameters.pfFinal = otherParameters.pfDB(:,I_best_index);
otherParameters.genCostsFinal = otherParameters.genCosts(I_best_index,:);
otherParameters.loadDRcostsFinal = otherParameters.loadDRcosts(I_best_index,:);
otherParameters.v2gChargeCostsFinal = otherParameters.v2gChargeCosts(I_best_index,:);
otherParameters.v2gDischargeCostsFinal =otherParameters.v2gDischargeCosts(I_best_index,:);
otherParameters.storageChargeCostsFinal = otherParameters.storageChargeCosts(I_best_index,:);
otherParameters.storageDischargeCostsFinal = otherParameters.storageDischargeCosts(I_best_index,:);
otherParameters.stBalanceFinal = otherParameters.stBalance(I_best_index,:,:);
otherParameters.v2gBalanceFinal = otherParameters.v2gBalance(I_best_index,:,:);
% otherParameters.pensVoltageUFinal =  otherParameters.pensVoltageU(I_best_index,:);
% otherParameters.pensVoltageLFinal = otherParameters.pensVoltageL(I_best_index,:);
% otherParameters.pensMaxSLinesFinal = otherParameters.pensMaxSLines(I_best_index,:);
otherParameters.penSlackBusFinal = otherParameters.penSlackBus(I_best_index,:);
objMaxVector = nan(length(obj_pop(1,:)),I_itermax);
objMaxVector(:,1)=obj_pop(I_best_index,:);

%------DE-Minimization---------------------------------------------
%------FM_popold is the population which has to compete. It is--------
%------static through one iteration. FM_pop is the newly--------------
%------emerging population.----------------------------------------
%FM_pm1   = zeros(I_NP,I_D);   % initialize population matrix 1
%FM_pm2   = zeros(I_NP,I_D);   % initialize population matrix 2
%FM_pm3   = zeros(I_NP,I_D);   % initialize population matrix 3
%FM_pm4   = zeros(I_NP,I_D);   % initialize population matrix 4
%FM_pm5   = zeros(I_NP,I_D);   % initialize population matrix 5
%FM_bm    = zeros(I_NP,I_D);   % initialize FVr_bestmember  matrix
%FM_ui    = zeros(I_NP,I_D);   % intermediate population of perturbed vectors
%FM_mui   = zeros(I_NP,I_D);   % mask for intermediate population
%FM_mpo   = zeros(I_NP,I_D);   % mask for old population
FVr_rot  = (0:1:I_NP-1);               % rotating index array (size I_NP)
%FVr_rotd = (0:1:I_D-1);       % rotating index array (size I_D)
%FVr_rt   = zeros(I_NP);                % another rotating index array
%FVr_rtd  = zeros(I_D);                 % rotating index array for exponential crossover
%FVr_a1   = zeros(I_NP);                % index array
%FVr_a2   = zeros(I_NP);                % index array
%FVr_a3   = zeros(I_NP);                % index array
%FVr_a4   = zeros(I_NP);                % index array
%FVr_a5   = zeros(I_NP);                % index array
%FVr_ind  = zeros(4);
%FM_meanv = ones(I_NP,I_D);

if deParameters.I_strategy==5;
    F_weight_old=repmat(F_weight,I_NP,1);
    F_weight= F_weight_old;
    F_CR_old=repmat(F_CR,I_NP,1);
    F_CR=F_CR_old;
end

if deParameters.I_strategy==10||deParameters.I_strategy==12||deParameters.I_strategy==13;
    
    if deParameters.I_strategyVersion==7||deParameters.I_strategyVersion==8;
        F_weight_old=repmat(F_weight,I_NP,4);
        F_weight= F_weight_old;
        F_CR_old=repmat(F_CR,I_NP,1);
        F_CR=F_CR_old;
    else
        F_weight_old=repmat(F_weight,I_NP,3);
        F_weight= F_weight_old;
        F_CR_old=repmat(F_CR,I_NP,1);
        F_CR=F_CR_old;
    end
end



if deParameters.I_strategy==7; %Based on DEPSO
    F_weight=rand(I_NP,1);
    F_CR=rand(I_NP,1);
end

if deParameters.I_strategy==9; %Based on DEPSO
    F_weight=rand(I_NP,3);
    F_CR=rand(I_NP,1);
end

I_strategyVersion=deParameters.I_strategyVersion;
 FM_arch=[];
while gen<=I_itermax %%&&  fitIterationGap >= threshold
    
    if adaptDE==1 %If adaptive DE is activated (JADE)
             
       F_weight_vec=F_weight + trnd(ones(I_NP,1)) * 0.1; % Cauchy distribution
       %F_weight_vec=F_weight + 0.1*tan(pi*(rand(I_NP,1)-1/2)); % Cauchy distribution
       F_CR_vec=F_CR+randn(I_NP,1) * 0.1; %Create CR around a normal distribution CR
        
       while sum(F_weight_vec<0)>0
              F_weight_vec(F_weight_vec<0)=F_weight + trnd(ones(sum(F_weight_vec<0),1)) * 0.1;
       end
       F_weight_vec(F_weight_vec>1)=1;
       F_CR_vec( F_CR_vec<0)=0;
       F_CR_vec( F_CR_vec>1)=1;
       
      [FM_ui,FM_base,~]=generate_trial(I_strategy,F_weight_vec, F_CR_vec, FM_pop, FVr_bestmemit,I_NP, I_D, FVr_rot,FM_arch);
    else
         if deParameters.I_strategy==5;
            value_R=rand(I_NP,2);
            ind1=value_R(:,1)<0.1;
            ind2=value_R(:,2)<0.1;
            F_weight(ind1)=0.1+rand(sum(ind1),1)*0.9;
            F_weight(~ind1)=F_weight_old(~ind1);
            F_CR(ind2)=rand(sum(ind2),1);
            F_CR(~ind2)=F_CR_old(~ind2);
         end
         
          if deParameters.I_strategy==10||deParameters.I_strategy==12||deParameters.I_strategy==13;
              
             if deParameters.I_strategyVersion==7||deParameters.I_strategyVersion==8;
                value_R=rand(I_NP,4);
                ind1=value_R<0.1;
                ind2=rand(I_NP,1)<0.1;
                F_weight(ind1)=0.1+rand(sum(sum(ind1)),1)*0.9;
                F_weight(~ind1)=F_weight_old(~ind1);
                F_CR(ind2)=rand(sum(ind2),1);
                F_CR(~ind2)=F_CR_old(~ind2);
             else
              
                value_R=rand(I_NP,3);
                ind1=value_R<0.1;
                ind2=rand(I_NP,1)<0.1;
                F_weight(ind1)=0.1+rand(sum(sum(ind1)),1)*0.9;
                F_weight(~ind1)=F_weight_old(~ind1);
                F_CR(ind2)=rand(sum(ind2),1);
                F_CR(~ind2)=F_CR_old(~ind2);
            end
         end
         
         
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        [FM_ui,FM_base,~]=generate_trial(I_strategy,F_weight, F_CR, FM_pop, FVr_bestmemit,I_NP, I_D, FVr_rot,FM_arch,I_strategyVersion);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if deParameters.I_strategy==7; %Based on DEPSO
            F_weight=F_weight+randn(I_NP,1)*0.2;
            F_CR=F_CR+randn(I_NP,1)*0.2;
            F_weight(F_weight<0.05)=0.05;
            F_weight(F_weight>1)=1;
            F_CR(F_CR<0)=0;
            F_CR(F_CR>1)=1;
        end
        
         if deParameters.I_strategy==9; %Based on DEPSO
            F_weight=F_weight+randn(I_NP,3)*0.2;
            F_CR=F_CR+randn(I_NP,1)*0.2;
            F_weight(F_weight<0.05)=0.05;
            F_weight(F_weight>1)=1;
            F_CR(F_CR<0)=0;
            F_CR(F_CR>1)=1;
        end
        
    end

%-----Optional parent+child selection-----------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % check signaling
    try
        if signaling_flag==1;
            [FM_ui,otherParameters] = checkSignaling(FM_ui,otherParameters,deParameters);
        end
    catch exception
        getReport(exception)
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-----Select which vectors are allowed to enter the new population------------
% Boundary Control
   FM_ui=update(FM_ui,minPositionsMatrix,maxPositionsMatrix,BRM,FM_base);
 %Evaluation of new Pop
%  [S_val_temp, obj_pop_temp, FM_ui_temp, otherParameters]=feval(fnc,FM_ui,caseStudyData, otherParameters);
   [S_val_temp, obj_pop_temp, ~, otherParameters]=feval(fnc,FM_ui,caseStudyData, otherParameters,10);

 % Elitist Selection
  ind=S_val_temp<S_val;
  S_val(ind)=S_val_temp(ind);
  FM_pop(ind,:)=FM_ui(ind,:);
  
  % update results
  [S_bestval,I_best_index] = min(S_val);
  FVr_bestmemit = FM_pop(I_best_index,:); % best member of current iteration
  % store fitness evolution and obj fun evolution as well
  fitMaxVector(gen) = S_bestval;
  
    if deParameters.I_strategy==5; %jDE
        F_weight_old(ind)=F_weight(ind);
        F_CR_old(ind)=F_CR(ind);
    end
     if deParameters.I_strategy==10||deParameters.I_strategy==12||deParameters.I_strategy==13; %jDE
        F_weight_old(ind,:)=F_weight(ind,:);
        F_CR_old(ind)=F_CR(ind);
    end

    if deParameters.I_strategy==6;  %JADE
        [~, ind_best]=sort(S_val); 
        FVr_bestmemit=FM_pop(ind_best(1:ceil(I_NP*0.15)),:); %This strategy is very similar to the one used for PSO modified
    end
 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if adaptDE==1 %If adaptive DE is activated
        FM_arch= [FM_arch; FM_pop(~ind,:)];
        if length(FM_arch(:,1))>I_NP
            hm=length(FM_arch(:,1))-I_NP;
            p = randperm(length(FM_arch(:,1)),hm);
            FM_arch( p,:)=[];
        end
        CR_iter(gen)=F_CR;
        F_iter(gen)=F_weight;
        % Update F and CR value
        if isempty(ind)==0
            a=0.1;
            W_F=F_weight_vec(ind);
            W_CR=F_CR_vec(ind);
            
            F_weight=(1-a)*F_weight+a*(sum(W_F.^2)/sum(W_F));
            F_CR=(1-a)*F_CR+a*(sum(W_CR)/length(W_CR));
           
            %F_CR=sum(W_CR)/sum(ind);
        end
        if gen==I_itermax
            plot(CR_iter)
            hold on
            plot(F_iter)
            BotherParameters.CR_iter=CR_iter;
            BotherParameters.F_iter=F_iter; 
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%----Output section----------------------------------------------------------
    if ind(I_best_index)
        % store other info
        otherParameters.idBestParticle = I_best_index;
%        otherParameters.pfFinal = otherParameters.pfDB(:,I_best_index);
        otherParameters.genCostsFinal = otherParameters.genCosts(I_best_index,:);
        otherParameters.loadDRcostsFinal = otherParameters.loadDRcosts(I_best_index,:);
        otherParameters.v2gChargeCostsFinal = otherParameters.v2gChargeCosts(I_best_index,:);
        otherParameters.v2gDischargeCostsFinal =otherParameters.v2gDischargeCosts(I_best_index,:);
        otherParameters.storageChargeCostsFinal = otherParameters.storageChargeCosts(I_best_index,:);
        otherParameters.storageDischargeCostsFinal = otherParameters.storageDischargeCosts(I_best_index,:);
        otherParameters.stBalanceFinal = otherParameters.stBalance(I_best_index,:,:);
        otherParameters.v2gBalanceFinal = otherParameters.v2gBalance(I_best_index,:,:);
%         otherParameters.pensVoltageUFinal =  otherParameters.pensVoltageU(I_best_index,:);
%         otherParameters.pensVoltageLFinal = otherParameters.pensVoltageL(I_best_index,:);
%         otherParameters.pensMaxSLinesFinal = otherParameters.pensMaxSLines(I_best_index,:);
        otherParameters.penSlackBusFinal = otherParameters.penSlackBus(I_best_index,:);
        objMaxVector(:,gen)= obj_pop_temp(I_best_index,:);
    elseif gen>1
        objMaxVector(:,gen)=objMaxVector(:,gen-1);
    end
  
%     if gen >= minGens
%         fitIterationGap = abs(fitMaxVector(gen)-mean(fitMaxVector(gen-1:-1:gen-1-noIterationsToGap)));
%     end
    
    gen=gen+1;

end %---end while ((I_iter < I_itermax) ...
%p1=sum(otherParameters.pensVoltageUFinal);
%p2=sum(otherParameters.pensVoltageLFinal);
%p3=sum(otherParameters.pensMaxSLinesFinal);
p1=sum(otherParameters.penSlackBusFinal);
Fit_and_p=[fitMaxVector(gen-1) p1]; %;p2;p3;p4]


        % store other info
        BotherParameters.idBestParticle = I_best_index;
%        BotherParameters.pfFinal = otherParameters.pfDB(:,I_best_index);
        BotherParameters.genCostsFinal = otherParameters.genCosts(I_best_index,:);
        BotherParameters.loadDRcostsFinal = otherParameters.loadDRcosts(I_best_index,:);
        BotherParameters.v2gChargeCostsFinal = otherParameters.v2gChargeCosts(I_best_index,:);
        BotherParameters.v2gDischargeCostsFinal =otherParameters.v2gDischargeCosts(I_best_index,:);
        BotherParameters.storageChargeCostsFinal = otherParameters.storageChargeCosts(I_best_index,:);
        BotherParameters.storageDischargeCostsFinal = otherParameters.storageDischargeCosts(I_best_index,:);
        BotherParameters.stBalanceFinal = otherParameters.stBalance(I_best_index,:,:);
        BotherParameters.v2gBalanceFinal = otherParameters.v2gBalance(I_best_index,:,:);
%         BotherParameters.pensVoltageUFinal =  otherParameters.pensVoltageU(I_best_index,:);
%         BotherParameters.pensVoltageLFinal = otherParameters.pensVoltageL(I_best_index,:);
%         BotherParameters.pensMaxSLinesFinal = otherParameters.pensMaxSLines(I_best_index,:);
         BotherParameters.penSlackBusFinal = otherParameters.penSlackBus(I_best_index,:);
%         %objMaxVector(:,gen)= obj_pop_temp(I_best_index,:);


% I VECTORIZED THE CODE INSTEAD OF USING FOR
function pop=genpop(a,b,lowMatrix,upMatrix)
pop=unifrnd(lowMatrix,upMatrix,a,b);

% I VECTORIZED THE CODE INSTEAD OF USING FOR
function p=update(p,lowMatrix,upMatrix,BRM,FM_base)

switch BRM

    case 1 %Our method
        %[popsize,dim]=size(p);
        [idx] = find(p<lowMatrix);
        p(idx)=lowMatrix(idx);
        [idx] = find(p>upMatrix);
        p(idx)=upMatrix(idx);
    case 2 %Random reinitialization
        [idx] = [find(p<lowMatrix);find(p>upMatrix)];
        replace=unifrnd(lowMatrix(idx),upMatrix(idx),length(idx),1);
        p(idx)=replace;
    case 3 %Bounce Back
      [idx] = find(p<lowMatrix);
      p(idx)=unifrnd(lowMatrix(idx),FM_base(idx),length(idx),1);
        [idx] = find(p>upMatrix);
      p(idx)=unifrnd(FM_base(idx), upMatrix(idx),length(idx),1);
end

function [FM_ui,FM_base,msg]=generate_trial(method,F_weight, F_CR, FM_pop, FVr_bestmemit,I_NP,I_D,FVr_rot,FM_arch,I_strategyVersion)

  FM_popold = FM_pop;                  % save the old population
  FVr_ind = randperm(4);               % index pointer array
  FVr_a1  = randperm(I_NP);                   % shuffle locations of vectors
  FVr_rt  = rem(FVr_rot+FVr_ind(1),I_NP);     % rotate indices by ind(1) positions
  FVr_a2  = FVr_a1(FVr_rt+1);                 % rotate vector locations
  FVr_rt  = rem(FVr_rot+FVr_ind(2),I_NP);
  FVr_a3  = FVr_a2(FVr_rt+1);                
  %FVr_rt  = rem(FVr_rot+FVr_ind(3),I_NP);
  %FVr_a4  = FVr_a3(FVr_rt+1);               
  %FVr_rt  = rem(FVr_rot+FVr_ind(4),I_NP);
  %FVr_a5  = FVr_a4(FVr_rt+1);                
  FM_pm1 = FM_popold(FVr_a1,:);             % shuffled population 1
  FM_pm2 = FM_popold(FVr_a2,:);             % shuffled population 2
  FM_pm3 = FM_popold(FVr_a3,:);             % shuffled population 3
  %FM_pm4 = FM_popold(FVr_a4,:);             % shuffled population 4
  %FM_pm5 = FM_popold(FVr_a5,:);             % shuffled population 5
  
 
  
if length(F_CR)==1  %Meaning the same F_CR for all individuals
    FM_mui = rand(I_NP,I_D) < F_CR;  % all random numbers < F_CR are 1, 0 otherwise
    FM_mpo = FM_mui < 0.5;    % inverse mask to FM_mui
else %Meaning a different F_CR for each individual
    FM_mui = rand(I_NP,I_D) < repmat(F_CR,1,I_D);  % all random numbers < F_CR are 1, 0 otherwise
    FM_mpo = FM_mui < 0.5;    % inverse mask to FM_mui
end


    switch method
        case 1,
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_pm3 + F_weight*(FM_pm1 - FM_pm2);   % differential variation
            else
                FM_ui = FM_pm3 + repmat(F_weight,1,I_D).*(FM_pm1 - FM_pm2);   % differential variation
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;     % crossover
            FM_base = FM_pm3;
            msg=' DE/rand/bin';
        case 2,
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            %VEC by FLC
            FM_bm=repmat(FVr_bestmemit,I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pm2);
            else
                FM_ui = FM_popold + repmat(F_weight,1,I_D).*(FM_bm-FM_popold) + repmat(F_weight,1,I_D).*(FM_pm1 - FM_pm2);
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';
        case 3,
            f1 = ((1-F_weight)*rand(I_NP,1)+F_weight);
            FM_pm5=repmat(f1,1,I_D); %Vectorized by FLC
            FM_ui = FM_pm3 + (FM_pm1 - FM_pm2).*FM_pm5;    % differential variation
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;     % crossover
            FM_base = FM_pm3;
            msg='DE/rand/with dither';
        case 4,
            if (rand < 0.5);                               % Pmu = 0.5
                if length(F_weight)==1  %Meaning the same F_weight for all individuals
                    FM_ui = FM_pm3 + F_weight*(FM_pm1 - FM_pm2);   % differential variation
                else
                    FM_ui = FM_pm3 + repmat(F_weight,1,I_D).*(FM_pm1 - FM_pm2);   % differential variation
                end
            else                                           % use F-K-Rule: K = 0.5(F+1)
                if length(F_weight)==1  %Meaning the same F_weight for all individuals
                    FM_ui = FM_pm3 + 0.5*(F_weight+1.0)*(FM_pm1 + FM_pm2 - 2*FM_pm3);
                else
                    FM_ui = FM_pm3 + repmat(0.5*(F_weight+1.0),1,I_D).*(FM_pm1 + FM_pm2 - 2*FM_pm3);
                end
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;     % crossover 
            FM_base = FM_pm3;
            msg='DE either or algorithm';
            
         case 5, %jDE
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_pm3 + F_weight*(FM_pm1 - FM_pm2);   % differential variation
            else
                FM_ui = FM_pm3 + repmat(F_weight,1,I_D).*(FM_pm1 - FM_pm2);   % differential variation
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;     % crossover
            FM_base = FM_pm3;
            msg=' DE/rand/bin';
            
         case 6, % JADE
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            FM_Union=[FM_pop;FM_arch];
            p = randperm(length(FM_Union(:,1)),I_NP);
            FM_pmu=FM_Union(p,:);
            %VEC by FLC
            FM_bm=repmat(FVr_bestmemit(randi(length(FVr_bestmemit(:,1))),:),I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pmu);
            else
                FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm-FM_popold) + repmat(F_weight(:,1),1,I_D).*(FM_pm1 - FM_pmu);
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';
            
         case 7, % DE modified
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            %VEC by FLC
            FM_bm=repmat(FVr_bestmemit(1,:),I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pm2);
            else
                FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(1+repmat(F_weight(:,1),1,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,1),1,I_D).*(FM_pm1 - FM_pm2);
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';
         case 8, % DE JADE
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            FM_Union=[FM_pop;FM_arch];
            p = randperm(length(FM_Union(:,1)),I_NP);
            FM_pmu=FM_Union(p,:);
            %VEC by FLC
            FM_bm=repmat(FVr_bestmemit(randi(length(FVr_bestmemit(:,1))),:),I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pmu);
            else
                FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(1+repmat(F_weight(:,1),1,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,1),1,I_D).*(FM_pm1 - FM_pmu);
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';
          case 9, % DE modified 3 Fs
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            %VEC by FLC
            FM_bm=repmat(FVr_bestmemit(1,:),I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pm2);
            else
                FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(1+repmat(F_weight(:,2),1,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';
        case 10, %jDEPerturbated_v1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
           FM_bm=repmat(FVr_bestmemit,I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pm2);
            else
                FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(1+repmat(F_weight(:,2),1,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';
            
        case 11, % DE modified
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            %VEC by FLC
            f1 = ((1-F_weight)*rand(I_NP,1)+F_weight);
            f2 = ((1-F_weight)*rand(I_NP,1)+F_weight);
            FM_pm5=repmat(f1,1,I_D); %Vectorized by FLC
            FM_pm6=repmat(f2,1,I_D); %Vectorized by FLC
            
            FM_bm=repmat(FVr_bestmemit,I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + FM_pm5.*(FM_bm.*(1+repmat(rand(I_NP,1),1,I_D).*randn(I_NP,I_D))-FM_popold) + FM_pm6.*(FM_pm1 - FM_pm2);
            else
                FM_ui = FM_popold + repmat(F_weight,1,I_D).*(FM_bm.*(1+repmat(F_weight(:,2),1,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight,1,I_D).*(FM_pm1 - FM_pm2);
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';
       
        case 12, %jDEPerturbated_v2
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
        FM_bm=repmat(FVr_bestmemit,I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pm2);
            else
                FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(repmat(F_weight(:,2),1,I_D)+rand(I_NP,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';
            
        case 13, %jDEPerturbated_v3 v4... v7
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
        FM_bm=repmat(FVr_bestmemit,I_NP,1);
            if length(F_weight)==1  %Meaning the same F_weight for all individuals
                FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pm2);
            else
                if  I_strategyVersion==2;
                    FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(repmat(F_weight(:,2),1,I_D)+rand(I_NP,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
                end
                if  I_strategyVersion==3;
                    FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(repmat(F_weight(:,2),1,I_D)+randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
                end
                if  I_strategyVersion==4;
                    FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*((-1+2*repmat(F_weight(:,2),1,I_D)).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
                end
                if I_strategyVersion==5;
                    FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*((-1+2*repmat(F_weight(:,2),1,I_D))+0.5*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
                end
                if I_strategyVersion==6;
                    FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*((-1+2*repmat(F_weight(:,2),1,I_D))+rand(I_NP,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
                end
                if I_strategyVersion==7;
                    FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*((-1+2*repmat(F_weight(:,2),1,I_D))+repmat(F_weight(:,4),1,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
                end
                 if I_strategyVersion==8;
                    FM_ui = FM_popold + repmat(F_weight(:,1),1,I_D).*(FM_bm.*(repmat(F_weight(:,2),1,I_D)+repmat(F_weight(:,4),1,I_D).*randn(I_NP,I_D))-FM_popold) + repmat(F_weight(:,3),1,I_D).*(FM_pm1 - FM_pm2);
                end
                 
                
            end
            FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
            FM_base = FM_bm;
            msg=' DE/current-to-best/1';   
            
            
            
    end
return

