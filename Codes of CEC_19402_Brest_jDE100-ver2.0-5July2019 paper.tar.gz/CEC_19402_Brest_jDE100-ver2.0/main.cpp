
//
//  Janez Brest, CEC 2019: 100-digit challenge
// 

// CEC'2019 paper: Janez Brest, Mirjam Sepesy Maucec, Borko Boskovic: The 100-Digit Challenge: Algorithm jDE100


#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>    // std::ostringstream
#include <cstdlib>    // drand48
#include <cmath>
#include <string>
#include <limits>
using namespace std;

void cec19_test_func(double *, double *,int,int,int);   // Janez
double *OShift,*M,*y,*z,*x_bound;
int ini_flag=0,n_flag,func_flag,*SS;

// CEC 2019 FUNCTIONS
const int nFun=10;      // number of functions
const int nRuns=50;     // number of runs (50 in CEC 2019)
int REZ[nFun][nRuns];   // data for Table 3 (number of correct digits)

const int myPrec=11;    // setprecision(myPrec) for cout
long mySeed;            // 
const double eps=1e-16;

const int maxNP = 100000;   // max. number for population size
const int maxD = 20;       // max. number for problem/function dimension
const unsigned long maxFES = (unsigned long)1e12;  // max. number of functions evaluations (very high number)

double P[maxNP][maxD];    // population NP x D; NP is population size, i.e., number of individuals

const int printVectorD=10;  // if D is smaller the print solution vectors
long nReset;                // reset counter
long sReset;                // reset counter

const long EMPTY=-1;         // Table2: If the given level of accuracy is not reached, leave the corresponding cell empty.

/* --------- jDE constants ----------- */
const double Finit  = 0.5;  // F   INITIAL FACTOR VALUE
const double CRinit = 0.9;  // CR  INITIAL FACTOR VALUE

double Fl = 0.1;         // (see bellow)     // F in the range []  //  F4=0.1 manjsi ne spila
const double Fu = 1.1;   //

double CRl = 0.0;        // see bellow    // CR in the range [0.0, 1.0]
const double CRu = 1.1;  //

const double tao1 = 0.1;   // probability to adjust F 
const double tao2 = 0.1;   // probability to adjust CR
const double myEqs = 0.25; // for reset populations

// [0, 1)
double mRandom() {
  //  return rand()/(RAND_MAX + 1.0);  
  return drand48();
}

// [0, val) intValue
unsigned int mRandomInt(int upper) {
  return (int)(upper * mRandom());
}

void initialization(double P[maxNP][maxD], const int NP, const int D, const double Xmin, const double Xmax) {
   for (int i = 0; i<NP; i++)
      for (int j = 0; j<D; j++) {
         P[i][j] = Xmin + mRandom()*(Xmax - Xmin); 
      }
}

void printIndividual(const double X[maxD], const int D) {  
   cout << " [";
   for (int j = 0; j<D; j++) {
      //if(j>2) { cout << "..."; break; }   // PRINT ONLY THREE
      cout << X[j];
      if (j != D-1) cout << ", ";
   }
   cout << "] ";
}

void printPOP(const double P[maxNP][maxD], const int NP, const int D, const double cost[maxNP]) {  // print POP E 
   for (int i = 0; i<NP; i++) {
      cout << i << " ";
      if (D <= printVectorD) printIndividual(P[i], D);  // smaller print else skip
      cout << " value= "<< cost[i] << endl;
   } 
}

double Dist(const double A[maxD], const double B[maxD], const int D) { 
   double dist=0.0;
   for (int j = 0; j<D; j++) 
      dist += (A[j]-B[j])* (A[j]-B[j]);
   // without sqrt(dist)
   return dist;
}
   
int crowding(const double P[maxNP][maxD], const double U[maxD], const int NP, const int D) { 
   double dist = Dist(P[0],U,D);
   double min_dist= dist;
   int min_ind = 0;
   for (int i = 1; i<NP; i++) {
      dist = Dist(P[i],U,D);
      if (dist < min_dist) {
         min_dist = dist; 
         min_ind = i;
      }
   }
   return min_ind;
}

// count how many individuals have similar fitness function value as the best one
int stEnakih(const double cost[], const int NP, const double cBest) {
   int eqs=0;  // equals
   for (int i = 0; i<NP; i++) {
      if(fabs(cost[i]-cBest) < eps)
         eqs++;
   }
   return eqs;
}

// Are there too many individuals that are equal (very close based on fitness) to the best one 
bool prevecEnakih(const double cost[], const int NP, const double cBest) {
   int eqs=0;  // equals
   for (int i = 0; i<NP; i++) {
      if(fabs(cost[i]-cBest) < eps)
         eqs++;
   }
   if(eqs>myEqs*NP) return true;
   else return false;
}

// count digits for CEC2019
int digits(double c) { 
   ostringstream ss;
   ss << setprecision(myPrec+1+10)<<c;
   string s = ss.str();

   // check if s is "1"  (without decimal point)
   if(s=="1") return 10;  // all digits are correct

   // check if s has not enough digits
   while (s.size() < 11) 
      s += "0";  // add "0" on the right
   const string ten="1.000000000";
   int nDig=0;
   if(ten[0] == s[0] && ten[1] == s[1]) {
      nDig=1;   // first digit is correct
      for(int i=2; i<(int)ten.length(); i++) {
         if(ten[i] == s[i]) nDig=i;
         else break;
      }
   }
   return nDig;
}

// print Table3    Score (see CEC2019 technical report)
void genTable3(const int REZ[nFun][nRuns]) {
   int DATA[nFun][11];    // data for Table 3 (number of correct digits)

   int dataOne[nRuns];    // data for one function, i.e. all runs
   double score[nFun];    // function scores
   double total=0.0;      // sum of scores
 
   for (int iFunk=0; iFunk<nFun; iFunk++) 
      for (int j=0; j < 11; j++)
         DATA[iFunk][j] = 0;

   for (int iFunk=0; iFunk<nFun; iFunk++) {
      for (int iRun=0; iRun<nRuns; iRun++) {
         int val=REZ[iFunk][iRun];
         DATA[iFunk][val]++;
         dataOne[iRun] = val; 
      }
      // sort dataOne
      for (int i=0; i<nRuns; i++)
         for (int j=0; j<nRuns-1; j++)
            if(dataOne[j] < dataOne[j+1]) {
               int tmp=dataOne[j];
               dataOne[j]=dataOne[j+1];
               dataOne[j+1]=tmp;
            }
       // calc score
       double sum=0;
       for(int i=0; i<nRuns/2; i++)   // 25 best runs 
          sum += dataOne[i];
       score[iFunk]=sum/(nRuns/2);
       total += score[iFunk];
   }
  
   ofstream outFile("table3.tex"); 
   outFile << "\\begin{table*}[ht]" << endl
           << "\\centering" << endl
           << "\\caption{ Fifty runs for each function sorted by the number of correct digits.} "<<endl
           << "\\label{tab:Score}" << endl
           << "\\begin{tabular}{|c|c|c|c|c|c|c|c|c|c|c|c|c|}" << endl
           << "\\hline" << endl
           << "\\multirow{2}{*}{Function} & \\multicolumn{11}{c|}{Number of correct digits}  & \\multirow{2}{*}{Score} \\\\" << endl
           << "\\cline{2-12}" << endl;
   outFile << "Function & "; for (int i=0; i<11; i++) outFile << i <<" & "; outFile << "Score \\\\"<<endl; 
   outFile << "\\hline" << endl;
   outFile << "\\hline" << endl;
   for (int iFunk=0; iFunk<nFun; iFunk++) {
      outFile << "F" << iFunk+1 << " & ";
      for (int j=0; j < 11; j++) {
         outFile << DATA[iFunk][j] << " & "; 
      }
      outFile << score[iFunk] <<" \\\\" << endl;  
      outFile << "\\hline" << endl;
   }
   outFile << "\\hline" << endl;
   outFile << "\\multicolumn{12}{|r|}{ Total: }& " << total << " \\\\" << endl;
   outFile << "\\hline" << endl;
   outFile << "\\end{tabular}"<<endl;
   outFile << "\\end{table*}"<<endl;
}


inline void genFES(const double c, long FR[nRuns][12], const int iRun, const long it) {
   int dig = digits(c);
   if (FR[iRun][dig] == -1) 
      FR[iRun][dig] = it;
}

int compare(long A[12], long B[12]) {  // return true if B "less-than" A
   for (int k=12-2; k>=0; k--) {  
      if(A[k] == EMPTY && B[k] == EMPTY) continue;
      if(A[k] == EMPTY && B[k] != EMPTY) return true;
      if(A[k] != EMPTY && B[k] == EMPTY) return false;
      return (A[k] > B[k]);
   }
   return false;
}

void genTable2(long FR[nRuns][12], const int iFunk, const int D) { // for each function
   for (int i=0; i<nRuns; i++) {     // complete missed data (in case, when two or more digits ...)
      for (int k=12-3; k>=0; k--) {  
         if(FR[i][k]== EMPTY && FR[i][k+1] != EMPTY) 
            FR[i][k]= FR[i][k+1];
      }
   }
   
   for (int i=0; i<nRuns; i++) {
      for (int j=0; j<nRuns-1; j++) {
         if (compare(FR[j],FR[j+1])) {   // sort based on FES (no sort on score)
            for (int k=0; k<12; k++) {  
               long tmp = FR[j][k];
               FR[j][k] = FR[j+1][k];
               FR[j+1][k] = tmp;
            }
         }
      }
   }
   
   ostringstream ss;
   ss << "jDE100_"<<iFunk+1<<"_"<<D<<".txt";
   string s = ss.str();
   ofstream outFile(s.c_str());
   for (int k=1; k<12; k++) {  // do not print zero digit
      for (int iRun=0; iRun<nRuns/2; iRun++) { // runs=50, here print 25
         outFile << FR[iRun][k] << " "; 
      }
      outFile << endl;
   }
   outFile.close();
}


//====================================================================================
int main() {

   cout << "********************************* " << endl;
   cout << "*** Algorithm jDE100 CEC 2019 *** " << endl;
   cout << "********************************* " << endl;
   //cout << "population size NP [5,"<<maxNP<<"]: ";
   int NP, bNP,sNP; // two populations, big and small
   bNP=1000;     // rez0059
   sNP=25;       // rez0059
   NP=bNP+sNP;   // both population size together

   if (NP < 5 || NP > maxNP) { cout << "Error maxNP! Increase maxNP"<<endl; exit(1); }

   // cout << "seedInit for random generator (long value): "; cin >> mySeed;
   // mySeed=1;
   mySeed=time(NULL);  // 
   cout << "seed: "<<mySeed<<endl;
   srand48(mySeed);    // seeding random generator drand48

   // CEC 2019 FUNCTIONS

   int D;                // DIMENSION
   double cost[maxNP];                 // vector of population costs (fitnesses)
   int indBest = 0;                    // index of best individual in current population
   double globalBEST[maxD];            // copy of GLOBAL BEST (we have restarts)
   double bestCOST = std::numeric_limits<double>::max(); // cost of globalBEST
   double parF[maxNP], parCR[maxNP];   // each individual has own F and CR
   double U[maxD];                     // trial vector
   
   // lower and upper bounds (the same for all components)
   double Xmin;  // angle are in radians
   double Xmax;
   unsigned long it;    // iteration counter
   unsigned long age;   // how many times the best cost does not improve
   unsigned long cCopy; // counter for copy

   for (int iFunk = 0; iFunk < nFun; iFunk++) {  // for each FUNCTION

      // *************  Tunable parameters, Fl and CRl
      Fl=0.15;
      if(iFunk==3) Fl=0.2;    // F4
      if(iFunk==6) Fl=0.2;    // F7
      if(iFunk==7) Fl=0.1;    // F8
      if(iFunk==8) Fl=0.001;  // F9
      CRl=0.0;
      if(iFunk==6) CRl=0.0;    // F7
      if(iFunk==7) CRl=0.1;    // F8
      if(iFunk==8) CRl=1.0;    // F9     // CRl=1.0 (junij 2019)


      long FR[nRuns][12];  // 0..10 digits + lastOne for FES
      for (int iRun=0; iRun<nRuns; iRun++)  // init
         for (int k=0; k<12; k++)  
         FR[iRun][k] = EMPTY;

      // Search range, dimension of the CEC 2019 benchmark functions
      if(iFunk+1 == 1)      { D=9;  Xmin=-8192;  Xmax=-Xmin; }   // Storn's ...
      else if(iFunk+1 == 2) { D=16; Xmin=-16384; Xmax=-Xmin; }   // Inverse Hilbert ...
      else if(iFunk+1 == 3) { D=18;  Xmin=-4;    Xmax=-Xmin; }   // Lennard-Joness ...
      else                  { D=10;  Xmin=-100;  Xmax=-Xmin; }   // Rastrigin's
      
      if (D < 2 || D > maxD) { cout << "Error maxD! (increase this value)" << endl; exit(1); }

      cout << "Function number=F"<<iFunk+1<<endl;
      cout << "Dimension D="<<D<<endl;
      cout << "Search range: Xmin="<<Xmin<<" Xmax="<<Xmax<<endl;
      cout << "Population size NP="<<NP<<" (bNP="<<bNP<<" sNP"<<sNP<<") "<<endl;

      for (int iRun=0; iRun<nRuns; iRun++) {  // for each RUN
         nReset=0;
         sReset=0;
         cCopy=0;
         age=0;
         indBest = 0;
         initialization(P,NP,D, Xmin, Xmax);
   
         for (int i=0; i<NP; i++) { 
            parF[i] = Finit;     // init
            parCR[i]= CRinit;    // init
         }

         // evaluate initialized population 
         for (int i=0; i<NP; i++) {
            cec19_test_func(P[i], &cost[i], D, 1, iFunk+1);  // evaluation results is returned in cost[i] 
            if (cost[i] < cost[indBest]) {
               indBest = i;
               //cout << "it="<<i<<" value="<<cost[indBest]<<" "; if (D <= printVectorD) printIndividual(P[indBest],D); cout << endl;
               genFES(cost[indBest], FR, iRun, (long)i);
            }
         }  
         bestCOST = cost[indBest]; 
         for (int j=0; j<D; j++)
            globalBEST[j] = P[indBest][j];   

         // main loop:  maxFES..maximum number of evaluations
         for (it=NP; it < maxFES; it++) {  // in initialization, NP function evaluations
            int i = it % (2*bNP);  
            int r1, r2, r3;
            double F, CR;
            double c;


/*    
if (it % 10000000==0)  {       
cout <<"   ...### Fun=F"<<iFunk+1<<" run="<<iRun+1<<" FES="<<it<< " NP="<<NP<< " D="<<D<< " valueBest="<<setprecision(myPrec+1+10)<<bestCOST<<" "; printIndividual(globalBEST,D); cout <<" digits="<<digits(bestCOST)<< " stEnakih="<<stEnakih(cost,NP,cost[indBest])<< " stEnakihbNP="<<stEnakih(cost,bNP,bestCOST)<<" nReset="<<nReset<<" sReset="<<sReset<<" cCopy="<<cCopy<<"  valueCurrBest="<<setprecision(myPrec+1+10)<<cost[indBest]<<" age="<<age<<" indBest="<<indBest<<" stEnakihsNP="<<stEnakih(&cost[bNP],sNP,cost[indBest])<<endl;
int mi=0; 
for(int w=0; w<bNP; w++) { 
  if (cost[w] < cost[mi]) mi=w;
}
cout << " bNP:: indBest="<<mi<<" value="<<setprecision(myPrec+1+10)<<cost[mi];
mi=bNP; 
for(int w=bNP; w<bNP+sNP; w++) { 
  if (cost[w] < cost[mi]) mi=w;
}
cout << " sNP:: indBest="<<mi<<" value="<<setprecision(myPrec+1+10)<<cost[mi]<<endl<<endl;
}
*/

            // reinitialization big population
            if (i==0 && ( prevecEnakih(cost,bNP,cost[indBest]) || age > 1e9 ) ) { 
               nReset++; 
               //cout << "   ...************* RESET **************  it="<<it <<" nReset="<<nReset <<"(age="<<age<<")  cost[indBest]= "<<cost[indBest]<<endl;

               for (int w = 0; w<bNP; w++) {   // TUKAJ
                  for (int j = 0; j<D; j++) {
                     P[w][j] = Xmin + mRandom()*(Xmax - Xmin); 
                  }
                  parF[w] = Finit;     // init
                  parCR[w]= CRinit;    // init
                  cost[w]=std::numeric_limits<double>::max();
               }
               age=0; 
               indBest=bNP; for (int w = bNP+1; w<NP; w++) { if(cost[w] < cost[indBest]) indBest=w; }
            }

            // reinitialization small pop
            if (i==bNP && indBest>=bNP && prevecEnakih(&cost[bNP],sNP,cost[indBest])) { 
               sReset++;
               //cout << "   ...************* reset small POP **************  it="<<it<< " sReset="<<sReset <<"   cost[indBest]= "<<cost[indBest]<<endl;
               for (int w = bNP; w<NP; w++) {
                  if(indBest==w) continue;
                  for (int j = 0; j<D; j++) {
                     P[w][j] = Xmin + mRandom()*(Xmax - Xmin); 
                  }
                  parF[w] = Finit;     // init
                  parCR[w]= CRinit;    // init
                  cost[w]=std::numeric_limits<double>::max();
               }
            }

            if (i==bNP && indBest < bNP) {   // copy best solution from the big pop in the small pop
               cCopy++;
               cost[bNP]=cost[indBest];
               for (int j = 0; j<D; j++) {
                  P[bNP][j]= P[indBest][j];
               }
               indBest=bNP;
            }

            if (i < bNP) {
               do { 
                  r1 = mRandomInt(bNP+0); 
               } while (r1 == i);  // 
               do { 
                  r2 = mRandomInt(bNP+1);        // HERE: index bNP is the first element in small pop
               } while (r2 == i || r2 == r1);
               do { 
                  r3 = mRandomInt(bNP+1);        // HERE: index bNP is the first element in small pop
               } while (r3 == i || r3 == r2 || r3 == r1);
            }
            else {
               i = (i-bNP) % sNP;
               do { 
                  r1 = mRandomInt(sNP); 
               } while (r1 == i );     
               do { 
                  r2 = mRandomInt(sNP); 
               } while (r2 == i || r2 == r1);
               do { 
                  r3 = mRandomInt(sNP); 
               } while (r3 == i || r3 == r2 || r3 == r1);
               r1 += bNP;
               r2 += bNP;
               r3 += bNP;
               i += bNP;
            }

            int jrand = mRandomInt(D);
   
            // SELF-ADAPTATION OF CONTROL PARAMETERS  jDE
            if (mRandom()<tao1) {                      // F
               F = Fl + mRandom() * Fu;
            }
            else {
               F = parF[i];
            }
            if (mRandom()<tao2) {                      // CR
               CR = CRl + mRandom() * CRu;
            }
            else {
               CR = parCR[i];
            }

            for(int j=0; j<D; j++) {    // mutation and crossover
               if (mRandom() < CR || j == jrand) {
                  U[j] = P[r1][j] + F*(P[r2][j] - P[r3][j]);  // DE/rand/1/bin (jDEbin)
                  
                  // border check  & repair 
                  while(U[j] < Xmin) { U[j] += (Xmax-Xmin); }    
                  while(U[j] > Xmax) { U[j] -= (Xmax-Xmin); }
                  // on border
                  //if(U[j] < Xmin) { U[j] = Xmin; }    
                  //if(U[j] > Xmax) { U[j] = Xmax; }
               }
               else {
                  U[j] = P[i][j];
               }
            }

            cec19_test_func(U, &c, D, 1, iFunk+1);  // c .. evaluation result   

            if(i<bNP) age++;

            // selection
            if (c < cost[indBest]) {   // best  (min)
               age=0;  // reset counter
               // globalBEST
               if (c < bestCOST) {
                  bestCOST = c;
                  for (int j=0; j<D; j++)
                  globalBEST[j] = U[j];   
               }
               
               cost[i] = c;
               for (int j=0; j<D; j++) P[i][j] = U[j];
               parF[i]=F;
               parCR[i]=CR;
               indBest = i;
               genFES(cost[indBest], FR, iRun, it);
               //cout << "   Fun="<<iFunk+1<<" run="<<iRun+1<<" nReset="<<nReset<<" sReset="<<sReset<<" cCopy="<<cCopy<<" NP="<<NP<<" it="<<it<<" i="<<i<<" valueBest="<<setprecision(myPrec)<<cost[indBest]<<" ";  if (D <= printVectorD)  printIndividual(P[i],D);  cout <<" F="<<parF[i]<<" CR="<<parCR[i]<< " gg="<<g<<((it%(2*bNP)<bNP)?" bNP ":" sNP ")<<endl; 
               if(cost[indBest] - 1.0 < 0.5E-9)   // 10-digits === 1. + 000 000 000 (9 zeros) and F(x*)=1.0
                  break;
            }
            else if (c <= cost[i]) {               // MIN
               cost[i] = c;
               for (int j=0; j<D; j++) P[i][j] = U[j];
               parF[i]=F;
               parCR[i]=CR;
            }
         } // it  (FEs counter)
         cout <<"Fun=F"<<iFunk+1<<" run="<<iRun+1<<" nReset="<<nReset<<" sReset="<<sReset<<" cCopy="<<cCopy<<" FES="<<it<< " NP="<<NP<<" (bNP="<<bNP<<" sNP"<<sNP<<") D="<<D<< "  bestValue="<<setprecision(myPrec+1+10)<<bestCOST<<" "; printIndividual(globalBEST,D); cout <<" "<<digits(bestCOST)<<endl;
         REZ[iFunk][iRun] = digits(cost[indBest]);
         FR[iRun][11] = it; // store FES at termination
      } // iRun
      genTable2(FR, iFunk, D);
   } // iFunk 

   genTable3(REZ);
   cout << "Done." << endl << endl;
   return 0;
}

